<?php
error_reporting(0);
$al=mysqli_connect("sql304.epizy.com","epiz_28594306_matrim","et1j3VfFccYYmqf","epiz_28594306_matrim");
?>